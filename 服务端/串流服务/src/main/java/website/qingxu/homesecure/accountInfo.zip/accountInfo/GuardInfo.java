package website.qingxu.homesecure.entity;

import lombok.Data;

@Data
public class GuardInfo {
    private long accountId;
    private String name;
}