import BoundaryUpdate.Operation;

import java.util.ArrayList;
import java.util.List;

public class patch {

    public List<LatLng> sendPoints = new ArrayList<>();

    public void display() {
        for (LatLng point:sendPoints) {
            System.out.println(point.latitude+" "+point.longitude);
        }
    }

    public void patchLine(LatLng old_point, LatLng new_point) {
        LatLng from = new LatLng(0,0);
        LatLng to = new LatLng(0,0);
        double x, y, dx, dy, k, it;
        dx = Operation.sub(new_point.longitude, old_point.longitude);
        dy = Operation.sub(new_point.latitude, old_point.latitude);
        System.out.println(dx+" "+dy);
        if (dx > 0) {
            from = old_point;
            to = new_point;
        } else {
            from = new_point;
            to = old_point;
        }
        if (dx != 0) {
            k = dy / dx;
            if (Math.abs(k) <= 1) {
                y = from.latitude;
                for (x = from.longitude; x <= to.longitude; x = Operation.sum(x, 0.000001)) {
                    LatLng point = new LatLng(x, (double) Math.round(y * 1000000) / 1000000);
                    sendPoints.add(point);
                    y = Operation.sum(y, k * 0.000001);
                }
            } else {
                System.out.println("2");
                k = 1 / k;
                if (dy > 0) {
                    from = old_point;
                    to = new_point;
                } else {
                    from = new_point;
                    to = old_point;
                }
                x = from.longitude;
                for (y = from.latitude; y <= to.latitude; y = Operation.sum(y, 0.000001)) {
                    LatLng point = new LatLng((double) Math.round(x * 1000000) / 1000000, y);
                    sendPoints.add(point);
                    x = Operation.sum(x, k * 0.000001);
                }
            }
        } else {
            if (dy > 0) {
                from = old_point;
                to = new_point;
            } else {
                from = new_point;
                to = old_point;
            }
            x = from.longitude;
            for (y = from.latitude; y <= to.latitude; y = Operation.sum(y, 0.000001)) {
                LatLng point = new LatLng(x, y);
                sendPoints.add(point);
            }
        }
    }
}
