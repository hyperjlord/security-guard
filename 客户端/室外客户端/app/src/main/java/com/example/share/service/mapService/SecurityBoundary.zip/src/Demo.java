import BoundaryUpdate.*;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class Demo {



    public static void main(String[] args) {
        Point point1 = new Point(10.000001,20.000001,0,0);
        Point point2 = new Point(10.000002,20.000002,0,0);
        Point point3 = new Point(10.000003,20.000003,0,0);
        Point point4 = new Point(10.000004,20.000004,0,0);
        Point point5 = new Point(10.000005,20.000005,0,0);

        Point point6 = new Point(10.000001,20.000005,0,0);
        Point point7 = new Point(10.000002,20.000004,0,0);
        Point point8 = new Point(10.000004,20.000002,0,0);
        Point point9 = new Point(10.000005,20.000001,0,0);

        Point point10 = new Point(10.000002, 20.000003, 0, 0);
        Point point11 = new Point(10.000003, 20.000002, 0, 0);
        Point point12 = new Point(10.000004, 20.000003, 0, 0);
        Point point13 = new Point(10.000003, 20.000004, 0, 0);

        Boundary boundary = new Boundary();
        boundary.addPoint(point3);
        boundary.addPoint(point10);
        boundary.addPoint(point11);
        boundary.addPoint(point12);
        boundary.addPoint(point13);

        Route route1 = new Route();
        route1.addPoint(point2);
        route1.addPoint(point5);

        Route route2 = new Route();
        route2.addPoint(point6);
        route2.addPoint(point7);
        route2.addPoint(point3);
        route2.addPoint(point8);
        route2.addPoint(point9);

        RouteSet routes = new RouteSet();
        routes.addRoute(route1);
        routes.addRoute(route2);

        //Initiate ini = new Initiate(routes, 3);
        // Update update = new Update(boundary, routes, 3);

        route1.patchSelf();
        while(!route1.route.isEmpty()){
            Point temp = route1.route.remove();
            temp.printLatLng();
        }
    }



}
