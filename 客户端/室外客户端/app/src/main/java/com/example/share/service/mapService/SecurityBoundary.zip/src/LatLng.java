public class LatLng {
    double latitude;
    double longitude;

    public LatLng(double lat, double lng) {
        this.latitude = lat;
        this.longitude = lng;
    }

}
